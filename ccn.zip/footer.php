<footer>	
		<!-- footer-top -->
		<div class="footer-top">
			<div class="container">
				<div class="col-md-6 footer-top-left">
					<h3><a href="index.html">CCNDEP</a></h3>
					<p>our company is Customer-focused on creating value among customers and making business more sustainable, efficient and profitable. We take care of customer passion, growth, innovative solutions and leadership in the market and provide it to our clients.</p>
					<ul class="fb_icons2">
						<li><a class="fb" href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
						<li><a class="twit" href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
						<li><a class="goog" href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
					</ul>
				</div>
				<div class="col-md-3 footer-top-mid">
					<h3>Our Company</h3>
					<ul>
						<li><a href="index.php"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Home</a></li>
						<li><a href="about.php"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>About</a></li>
						
						<li><a href="contact.php"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Contact</a></li>
					</ul>
				</div>
				<div class="col-md-3 adress-agile">
					<h3>Address</h3>
					<address>
						<ul>
							<li><span class="glyphicon glyphicon-map-marker" aria-hidden="true"></span>E-605,SDS NRI</li>
							<li>Pari Chowk,</li>
							<li>Greater Noida,UP</li>
							<li>Pin:201303</li>
							<li><span class="glyphicon glyphicon-earphone" aria-hidden="true"></span>&nbsp; 9582888093</li>
							<li>Email : <a class="mail" href="mailto:contactus@ccndep.com">contactus@ccndep.com</a></li>
						</ul>
					</address>				
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
		<!-- //footer-top -->
		<div class="w3layouts-copyright">
			<p class="footer"><a href="../login.php"><span style="color:white;"><b>&copy; 2016 CCNDEP</b></span></a></p>
		</div>
	</footer>