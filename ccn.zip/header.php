
		<header>
	<div class="container">
			<!-- nav -->
			<nav class="navbar navbar-inverse navbar-static-top">
			  <div class="container-fluid">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
				  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				  </button>
				<div class="logo">
					<a href="index.php"><img src="images/logo.png" width="50" height="50"></a>
				</div>	
				</div>

				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
				  <ul class="nav navbar-nav">
					<li><a href="index.php"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>&nbsp;Home</a></li>
					<li class=""><a href="about.php"><span class="glyphicon glyphicon-search" aria-hidden="true"></span> &nbsp;About</a></li>
					
					<li><a href="contact.php"><span class="glyphicon glyphicon-hand-right" aria-hidden="true"></span>&nbsp;Contact</a></li>
				  </ul>
				</div>
				<!-- /.navbar-collapse -->
			  </div>
			  <!-- /.container-fluid -->
			</nav> 
			<script src="js/nav.js"></script><!-- nav-js --> 
			<!-- //nav -->
		</div>
		</header>
		<div class="clearfix"></div>